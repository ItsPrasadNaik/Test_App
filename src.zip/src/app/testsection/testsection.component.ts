import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testsection',
  templateUrl: './testsection.component.html',
  styleUrls: ['./testsection.component.css']
})
export class TestsectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
